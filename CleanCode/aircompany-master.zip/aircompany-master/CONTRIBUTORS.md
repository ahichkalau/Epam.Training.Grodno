Original pretty version
=======================
* Sergei Volchek
* Aliaksei Safronau

Final corrupted version with voilations
=======================================
* Vitali Shulha